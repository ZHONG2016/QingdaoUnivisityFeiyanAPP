/**
 * 总体配置文件
 */

var API = {
		basePath : "http://localhost:8080/Friendship/",
		login : "login.action",
		register : "register.action",
		modify : "modify.action",
		getFuns : "getFuns.action",
		addGz : "addGz.action",
		manageFans : "manageFans.action",
		getGuanzhu : "getGuanzhu.action",
		cancelGz : "cancelGz.action",
		getMyRecommend : "getMyRecommend.action",
		publish : "publish.action",
		manage : "manage.action",
		search : "recommands.action",
		reply : "reply.action",
		getReplys : "getReplys.action"
};