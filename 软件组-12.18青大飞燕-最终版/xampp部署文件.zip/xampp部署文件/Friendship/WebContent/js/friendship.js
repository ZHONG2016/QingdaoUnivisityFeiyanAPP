/**
 * 
 */
var LoginUser = null;

if(localStorage){
	var s = localStorage.getItem('loginUser');
	if(s)
		LoginUser = JSON.parse(s);
}

function login(){
	var loginName = $('#loginName').val();
	var password = $('#password').val();
	if('' == loginName){
		alert('请输入登录名.');
		return;
	}
	if('' == password){
		alert('请输入密码.');
		return;
	}
	var d = 'name='+loginName+'&pwd='+password;
	$.post(API.basePath + API.login,d,function(data,status){
		console.log(data);
		if('success' == status){
			if(data == ''){
				alert('登录失败，错误的用户名或密码.');
			}else{
				alert('登录成功.');
				if(localStorage)
					localStorage.setItem('loginUser',JSON.stringify(data));
				location.href = "index.html";
			}
		}
	});
}

function exit(){
	if(confirm('您确定要退出吗？') != 1)
		return;
	if(localStorage)
		localStorage.removeItem('loginUser');
	LoginUser = null;
	location.href="index.html";
}

function register(){
	var loginName = $('#loginName').val();
	var password = $('#password').val();
	var confirmPassword = $('#confirmPassword').val();
	
	if('' == loginName){
		alert('请输入登录名.');
		return;
	}
	if('' == password){
		alert('请输入密码.');
		return;
	}
	if('' == confirmPassword){
		alert('请再次输入密码.');
		return;
	}else if(password != confirmPassword){
		alert('两次输入的密码不一致，请重新输入.');
		return;
	}
	
	var d = 'name='+loginName+'&pwd='+password;
	$.post(API.basePath + API.register,d,function(data,status){
		console.log(data);
		if('success' == status){
			if(data.state == 1){
				alert('注册成功.');
				location.href = "login.html";
			}else if(data.state = 0){
				alert('注册失败，可能已经存在该用户名了，请使用其他用户名重试.');
			}
		}
	});
}

function initUserInfo(){
	if(null == LoginUser){
		location.href = 'login.html';
		return;
	}
	$('#nickName').val(LoginUser.nickName);
	$('#headImage').val(LoginUser.headImage);
	$('#qq').val(LoginUser.qq);
}

function modify(){
	var nickName = $('#nickName').val();
	var headImage = $('#headImage').val();
	var qq = $('#qq').val();
	var d = 'nickName='+nickName+'&headImage='+headImage+'&qq='+qq+'&uid='+LoginUser.uid;
	$.post(API.basePath + API.modify,d,function(data,status){
		console.log(data);
		if('success' == status){
			if(data.state == 1){
				alert('修改成功.');
				LoginUser.nickName = nickName;
				LoginUser.headImage = headImage;
				LoginUser.qq = qq;
				if(localStorage)
					localStorage.setItem('loginUser',JSON.stringify(LoginUser));
				location.href = "manage.html";
			}else if(data.state == 0){
				alert('修改失败.');
			}
		}
	});
}

function publish(){
	var title = $('#title').val();
	var content = $('#content').val();
	var tag = $('#tag').val();
	var d = 'title='+title+'&content='+content+'&tag='+tag+'&uid='+LoginUser.uid;
	$.post(API.basePath + API.publish,d,function(data,status){
		console.log(data);
		if('success' == status){
			if(data.state == 1){
				alert('发布成功.');
				location.href = "recommendManage.html";
			}else if(data.state == 0){
				alert('发布失败.');
			}
		}
	});
}

function getMyRecommend(){
	var ml = $('#myrecommends');
	ml.html('');
	$.post(API.basePath + API.getMyRecommend,'uid='+LoginUser.uid,function(data,status){
		console.log(data);
		if('success' == status){
			if(data){
				var temp = $('#mrmds_temp').html();
				if(data.length == 0){
					ml.append('<li><button class="btn btn-primary btn-block">还未发布推荐信息</button></li>');
					return;
				}
				for(var i=0,len=data.length;i<len;i++){
					var item = data[i];
					ml.append(temp.replace('${title}',item.title).replace('${uid}',item.uid).replace('${createTime}',item.createTime).replace('${content}',item.content).replace('${tid}',item.id));
				}
			}
		}
	});
}

function delMyRmd(id){
	$.post(API.basePath + API.manage,'uid='+LoginUser.uid+'&tid='+id,function(data,status){
		console.log(data);
		if('success' == status){
			if(data){
				if(data.state == 1){
					alert('删除成功.');
					location.href = "recommendManage.html";
				}else{
					alert('删除失败.');
				}
			}
		}
	});
}

function initIndexData(){
	if(null != LoginUser){
		$('#filterBar').show();
		$('#viewAll').bind("click",function(){
			search(1);
		});
		$('#viewGz').bind("click",function(){
			search(2);
		});
	}
	search(1);
}

function search(type,tag){
	var d = '';
	if(type == 2 && null != LoginUser){
		d = 'uid='+LoginUser.uid;
	}
	if(typeof(tag) == 'undefined'){
		d = d+'&type='+type;
	}else{
		d = d+'&type='+type+'&tag='+tag;
	}
	var rl = $('#resultList');
	rl.html('');
	
	$.post(API.basePath + API.search,d,function(data,status){
		console.log(data);
		if('success' == status){
			var tmp = $('#tmp').html();
			if(data && data.length > 0){
				for(var i=0,len=data.length;i<len;i++){
					var item = data[i];
					rl.append(tmp.replaceAll('{uid}',item.uid).replaceAll('{nickname}',item.nickName).replaceAll('{content}',item.content).replaceAll('{tag}',item.tag).replaceAll('{id}',item.id));
				}
			}
		}
	});
	
}

function showReply(id){
	if(null == LoginUser){
		alert('请登陆后添加关注.');
		return;
	}
	$('#reply_'+id).toggle();
}

function sendReply(id){
	var replyValue = $('#replyval_'+id).val();
	if('' == replyValue){
		alert('请输入评论内容.');
		return;
	}
	var d = 'tid='+id+'&replyUid='+LoginUser.uid+'&content='+replyValue;
	$.post(API.basePath + API.reply,d,function(data,status){
		console.log(data);
		if('success' == status){
			if(data.state == 1){
				alert('评论成功.');
				$('#replyval_'+id).val('');
				showReply(id);
			}else {
				alert('评论失败.');
			}
		}
	});
}

function viewReply(tid){
	var rl = $('#sssss_'+tid);
	rl.html('');
	var d = 'tid='+tid;
	$.post(API.basePath + API.getReplys,d,function(data,status){
		console.log(data);
		if('success' == status){
			if(data){
				var tmp = $('#replyTmp').html();
				for(var i=0,len=data.length;i<len;i++){
					var item = data[i];
					if(item.headImage == null || item.headImage == ''){
						item.headImage = 'http://placehold.it/42x42';
					}
					var h = tmp.replaceAll('{tid}',item.tid).replaceAll('{headImage}',item.headImage).replaceAll('{nickName}',item.nickName).replaceAll('{replyContent}',item.replyContent);
					rl.append(h);
				}
			}
		}
	});
}

function addGz(guanzhuUid){
	if(null == LoginUser){
		alert('请登陆后添加关注.');
		return;
	}
	if(LoginUser.uid == guanzhuUid){
		alert('不能自己关注自己哦.');
		return;
	}
	var d = 'myUid='+LoginUser.uid+'&gzUid='+guanzhuUid;
	$.post(API.basePath + API.addGz,d,function(data,status){
		console.log(data);
		if('success' == status){
			if(data.state == 1){
				alert('添加关注成功.');
			}else if(data.state == 2){
				alert('您已经关注过这个用户啦.');
			}else {
				alert('添加关注失败.');
			}
		}
	});
}

function getFans(){
	var d = 'myUid='+LoginUser.uid;
	var fl = $('#fansList');
	fl.html('');
	$.post(API.basePath + API.getFuns,d,function(data,status){
		console.log(data);
		if('success' == status){
			if(data && data.length > 0){
				var len = data.length;
				$('#fansCount').html(len);
				for(var i=0;i<len;i++){
					var item = data[i];
					var temp = $('#fansTmp').html();
					if(item.headImage == null || item.headImage == ''){
						item.headImage = 'http://placehold.it/42x42';
					}
					fl.append(temp.replaceAll('{headImage}',item.headImage).replaceAll('{nickName}',item.nickName).replaceAll('{qq}',item.qq).replaceAll('{fansUid}',item.myUid));
				}
			}
		}
	});
}

function delFans(fansUid){
	var d = 'myUid='+fansUid+'&gzUid='+LoginUser.uid;
	$.post(API.basePath + API.manageFans,d,function(data,status){
		console.log(data);
		if('success' == status){
			if(data.state == 1){
				alert('粉丝删除成功.');
				location.reload(true);
			}else {
				alert('粉丝删除失败.');
			}
		}
	});
}

function getMyGzUsers(){
	var d = 'myUid='+LoginUser.uid;
	var gl = $('#gzUserList');
	gl.html('');
	$.post(API.basePath + API.getGuanzhu,d,function(data,status){
		console.log(data);
		if('success' == status){
			if(data && data.length > 0){
				var len = data.length;
				$('#gzCount').html(len);
				for(var i=0;i<len;i++){
					var item = data[i];
					var temp = $('#gzTemp').html();
					if(item.headImage == null || item.headImage == ''){
						item.headImage = 'http://placehold.it/42x42';
					}
					gl.append(temp.replaceAll('{headImage}',item.headImage).replaceAll('{nickName}',item.nickName).replaceAll('{onTime}',item.onTime).replaceAll('{gzUid}',item.guanzhuUid));
				}
			}
		}
	});
}

function cancelFocus(gzUid){
	var d = 'myUid='+LoginUser.uid+'&gzUid='+gzUid;
	$.post(API.basePath + API.cancelGz,d,function(data,status){
		console.log(data);
		if('success' == status){
			if(data.state == 1){
				alert('已取消关注.');
				location.reload(true);
			}else {
				alert('操作失败.');
			}
		}
	});
}

String.prototype.replaceAll = function(p1,p2,ig){
	if(!RegExp.prototype.isPrototypeOf(p1)){
		return this.replace(new RegExp(p1,(ig?"gi":"g")),p2);
	}else{
		return this.replace(p1, p2);
	}
}