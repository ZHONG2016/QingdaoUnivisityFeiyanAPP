package com.friend.db;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class JdbcConfig {
	public static String driver;
	public static String url;
	public static String user;
	public static String password;
	public static int logintimeout = 60;
	
	public static void load(){
		Properties properties = new Properties();
		try {
			properties.load(JdbcConfig.class.getResourceAsStream("/jdbc.properties"));
			JdbcConfig.driver = properties.getProperty("driver");
			JdbcConfig.url = properties.getProperty("url");
			JdbcConfig.user = properties.getProperty("user");
			JdbcConfig.password = properties.getProperty("password");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
