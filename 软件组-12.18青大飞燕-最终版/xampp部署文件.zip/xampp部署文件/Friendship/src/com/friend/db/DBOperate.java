package com.friend.db;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;
import java.util.Hashtable;

public class DBOperate {
	private static final String ST = "Statement";
	private static final String PS = "PreparedStatement";
	private static final String CS = "CallableStatement";
	  
	public Connection conn = null;
	private Hashtable<Object, String> states = new Hashtable<Object, String>();

	boolean isUse = false;
	int uses = 0;
	long lastAccess = 0L;

	static{
		JdbcConfig.load();
	}
	
	public DBOperate() {
		setConnection();
	}
	
	public void setConnection(){
		try {
			Class.forName(JdbcConfig.driver);

			DriverManager.setLoginTimeout(JdbcConfig.logintimeout);

			this.conn = DriverManager.getConnection(JdbcConfig.url, JdbcConfig.user, JdbcConfig.password);

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() {
		return this.conn;
	}

	public void setAutoCommit(boolean isAuto) {
		try {
			this.conn.setAutoCommit(isAuto);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void commit() {
		try {
			this.conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void rollback() {
		try {
			this.conn.rollback();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public Statement statement() {
		Statement st = null;
		try {
			st = this.conn.createStatement();
		} catch (SQLException e) {
			freeConnection();
			st = statement();
			e.printStackTrace();
		}
		this.states.put(st, ST);
		return st;
	}

	public Statement statement(int rsType, int rsConcurrency) {
		Statement st = null;
		try {
			st = this.conn.createStatement(rsType, rsConcurrency);
		} catch (SQLException e) {
			freeConnection();
			st = statement(rsType, rsConcurrency);
			e.printStackTrace();
		}
		this.states.put(st, ST);
		return st;
	}

	public PreparedStatement preparedStatement(String sql) throws SQLException {
		PreparedStatement pst = null;

		pst = this.conn.prepareStatement(sql);

		this.states.put(pst, PS);
		return pst;
	}

	public PreparedStatement preparedStatement(String sql, int rsType,
			int rsConcurrency) throws SQLException {
		PreparedStatement pst = null;

		pst = this.conn.prepareStatement(sql, rsType, rsConcurrency);

		this.states.put(pst, PS);
		return pst;
	}

	public CallableStatement preparedCall(String sql, int rsType,
			int rsConcurrency) throws SQLException {
		CallableStatement cst = null;

		cst = this.conn.prepareCall(sql, rsType, rsConcurrency);

		this.states.put(cst, CS);
		return cst;
	}

	public CallableStatement preparedCall(String sql) throws SQLException {
		CallableStatement cst = null;

		cst = this.conn.prepareCall(sql);

		this.states.put(cst, CS);
		return cst;
	}

	public boolean isExistsDB(String dbname){
		return isHasRecord("INFORMATION_SCHEMA.SCHEMATA", "SCHEMA_NAME = '"+dbname+"'");
	}

	public boolean isExistsTable(String table){
		return isExistsTable(table);
	}

	public boolean isExistsTable(String dbname,String table){
		return isHasRecord("INFORMATION_SCHEMA.TABLES", "TABLE_SCHEMA = '"+dbname+"' AND TABLE_NAME = '"+table+"'");
	}
	
	public void freeConnection() {
		if (this.conn == null)
			return;
		Enumeration<Object> sts = this.states.keys();

		while (sts.hasMoreElements()) {
			Object obj = sts.nextElement();
			if (obj != null) {
				String flag = (String) this.states.get(obj);
				try {
					if (ST.equals(flag))
						((Statement) obj).close();
					else if (PS.equals(flag))
						((PreparedStatement) obj).close();
					else if (CS.equals(flag))
						((CallableStatement) obj).close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		this.states.clear();
	}

	public boolean isHasRecord(String table, String conds) {
		boolean isHas = false;
		String sql = "select count(*) from " + table + " where " + conds;
		try {
			Statement st = this.conn.createStatement();
			ResultSet rs = st.executeQuery(sql);

			while (rs.next()) {
				if (rs.getInt(1) > 0)
					isHas = true;
			}
			rs.close();
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			freeConnection();
		}
		return isHas;
	}

	public boolean execSQL(String sql) {
		boolean isOk = false;
		try {
			Statement st = this.conn.createStatement();

			st.execute(sql);
			isOk = true;

			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			freeConnection();
		}
		return isOk;
	}

	public String getFieldValue(String table, String field, String where) {
		String sql = "select " + field + " from " + table;
		if ((where != null) && (where.length() > 0)) {
			sql = sql + " where " + where;
		}
		String result = null;
		try {
			Statement st = this.conn.createStatement();

			for (ResultSet rs = st.executeQuery(sql); rs.next();) {
				result = rs.getString(1);
			}
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			freeConnection();
		}

		return result;
	}

	public boolean excuteCall(String sql) {
		boolean isOk = false;
		try {
			setAutoCommit(false);
			CallableStatement cst = preparedCall(sql);
			cst.execute();
			commit();
			isOk = true;
		} catch (Exception e) {
			rollback();
			e.printStackTrace();
		} finally {
			setAutoCommit(true);
			freeConnection();
		}
		return isOk;
	}


	public Connection getConn() {
		return this.conn;
	}

	public void setConn(Connection conn) {
		this.conn = conn;
	}

	public Hashtable<Object, String> getStates() {
		return this.states;
	}

	public void setStates(Hashtable<Object, String> states) {
		this.states = states;
	}

	public boolean isUse() {
		return this.isUse;
	}

	public void setUse(boolean isUse) {
		this.isUse = isUse;
	}

	public int getUses() {
		return this.uses;
	}

	public void setUses(int uses) {
		this.uses = uses;
	}

	public long getLastAccess() {
		return this.lastAccess;
	}

	public void setLastAccess(long lastAccess) {
		this.lastAccess = lastAccess;
	}
}