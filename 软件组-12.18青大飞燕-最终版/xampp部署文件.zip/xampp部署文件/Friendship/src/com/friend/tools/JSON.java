package com.friend.tools;


import java.io.IOException;
import java.io.StringWriter;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.map.ObjectMapper;


public class JSON {
	
	//thread safe & do cache
	private static ObjectMapper mapper = new ObjectMapper();
	
	public static String stringify(Object obj){
		StringWriter sw = new StringWriter();
		JsonGenerator jsonGenerator = null;
		try {
			jsonGenerator = mapper.getJsonFactory().createJsonGenerator(sw);
			mapper.writeValue(jsonGenerator, obj);
		} catch (IOException e) {
			e.printStackTrace();
		} finally{
			if(null != jsonGenerator){
				try {
					jsonGenerator.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		return sw.toString();
	}
	
	public static Object parse(String json, Class<?> clazz){
		Object obj = null;
		try {
			obj = mapper.readValue(json, clazz);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return obj;
	}
}
