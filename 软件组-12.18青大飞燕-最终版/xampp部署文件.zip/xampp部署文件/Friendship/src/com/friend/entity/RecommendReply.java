package com.friend.entity;

import java.io.Serializable;

public class RecommendReply implements Serializable {

	private static final long serialVersionUID = 1L;
	private int id;
	private int tid;
	private int replyUid;
	private String replyContent;
	private String replyTime;
	private String nickName;
	private String headImage;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public int getReplyUid() {
		return replyUid;
	}
	public void setReplyUid(int replyUid) {
		this.replyUid = replyUid;
	}
	public String getReplyContent() {
		return replyContent;
	}
	public void setReplyContent(String replyContent) {
		this.replyContent = replyContent;
	}
	public String getReplyTime() {
		return replyTime;
	}
	public void setReplyTime(String replyTime) {
		this.replyTime = replyTime;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getHeadImage() {
		return headImage;
	}
	public void setHeadImage(String headImage) {
		this.headImage = headImage;
	}
	
	
}
