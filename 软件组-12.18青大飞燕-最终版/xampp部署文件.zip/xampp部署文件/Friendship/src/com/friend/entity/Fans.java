package com.friend.entity;

import java.io.Serializable;

public class Fans implements Serializable {

	private static final long serialVersionUID = 1L;
	private int id;
	private int myUid;
	private int guanzhuUid;
	private String headImage;
	private String nickName;
	private String qq;
	private String onTime;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getMyUid() {
		return myUid;
	}
	public void setMyUid(int myUid) {
		this.myUid = myUid;
	}
	public int getGuanzhuUid() {
		return guanzhuUid;
	}
	public void setGuanzhuUid(int guanzhuUid) {
		this.guanzhuUid = guanzhuUid;
	}
	public String getHeadImage() {
		return headImage;
	}
	public void setHeadImage(String headImage) {
		this.headImage = headImage;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getQq() {
		return qq;
	}
	public void setQq(String qq) {
		this.qq = qq;
	}
	public String getOnTime() {
		return onTime;
	}
	public void setOnTime(String onTime) {
		this.onTime = onTime;
	}
	
	
}
