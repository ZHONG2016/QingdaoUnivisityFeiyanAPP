package com.friend.action;

import java.io.IOException;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;

public class BaseAction extends ActionSupport {
	private static final long serialVersionUID = 1L;
	
	protected HttpServletRequest request(){
		return ServletActionContext.getRequest();
	}
	
	protected HttpServletResponse response(){
		return ServletActionContext.getResponse();
	}
	
	protected void setReqAttribute(String name,Object object){
		request().setAttribute(name, object);
	}
	
	protected String getParameter(String name){
		return request().getParameter(name);
	}
	
	protected void print(String s){
		try {
			response().getWriter().print(s);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public boolean deleteCookie(String key){
		Cookie[] cookies = request().getCookies();
		if(null != cookies){
			for (Cookie cookie : cookies) {
				if(cookie.getName().equals(key)){
					cookie.setMaxAge(0);
					response().addCookie(cookie);
					return true;
				}
			}
		}
		return false;
	}
	
	public void contentType(String contentType){
		response().setContentType(contentType);
	}
}
