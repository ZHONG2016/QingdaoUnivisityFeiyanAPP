package com.friend.action;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cybermall.common.util.Tools;
import com.friend.db.DBOperate;
import com.friend.entity.Fans;
import com.friend.entity.Recommand;
import com.friend.entity.RecommendReply;
import com.friend.entity.User;
import com.friend.tools.JSON;

public class FriendshipAction extends BaseAction {

	private static final long serialVersionUID = 1L;
	
	public void login(){
		String loginName = getParameter("name");
		String password = getParameter("pwd");
		
		DBOperate db = new DBOperate();
		try {
			String sql = "SELECT * FROM user WHERE loginName = ? AND password = ?";
			PreparedStatement pstmt = db.preparedStatement(sql);
			pstmt.setString(1, loginName);
			pstmt.setString(2, password);
			
			ResultSet resultSet = pstmt.executeQuery();
			if(resultSet.next()){
				contentType("text/json;charset=UTF-8");
				User user = new User();
				user.setUid(resultSet.getInt("uid"));
				user.setNickName(resultSet.getString("nickName"));
				user.setHeadImage(resultSet.getString("headImage"));
				user.setQq(resultSet.getString("qq"));
				print(JSON.stringify(user));
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			db.freeConnection();
		}
		print("");
	}
	
	public void register(){
		String loginName = getParameter("name");
		String password = getParameter("pwd");
		
		DBOperate db = new DBOperate();
		try {
			String sql = "INSERT INTO user(loginName,password,regTime) VALUES(?,?,?)";
			PreparedStatement pstmt = db.preparedStatement(sql);
			pstmt.setString(1, loginName);
			pstmt.setString(2, password);
			pstmt.setTimestamp(3, new Timestamp(new Date().getTime()));
			
			if(pstmt.executeUpdate() > 0){
				contentType("text/json;charset=UTF-8");
				print("{\"state\":1}");
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			db.freeConnection();
		}
		print("{\"state\":0}");
	}
	
	/**
	 * 修改个人资料
	 */
	public void modify(){
		String nickName = getParameter("nickName");
		String headImage = getParameter("headImage");
		String qq = getParameter("qq");
		int uid = Tools.parseInt(getParameter("uid"));
		
		contentType("text/json;charset=UTF-8");
		DBOperate db = new DBOperate();
		try {
			String sql = "UPDATE user SET nickName = ?, headImage = ?, qq = ? WHERE uid = ?";
			PreparedStatement pstmt = db.preparedStatement(sql);
			pstmt.setString(1, nickName);
			pstmt.setString(2, headImage);
			pstmt.setString(3, qq);
			pstmt.setInt(4, uid);
			
			if(pstmt.executeUpdate() > 0){
				print("{\"state\":1}");
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			db.freeConnection();
		}
		print("{\"state\":0}");
	}
	
	/**
	 * 发布推荐信息
	 */
	public void publish(){
		String title = getParameter("title");
		String content = getParameter("content");
		String tag = getParameter("tag");
		int uid = Tools.parseInt(getParameter("uid"));
		contentType("text/json;charset=UTF-8");
		
		DBOperate db = new DBOperate();
		try {
			String sql = "INSERT INTO recommend(uid,title,content,tag,createTime) VALUES(?,?,?,?,?)";
			PreparedStatement pstmt = db.preparedStatement(sql);
			pstmt.setInt(1, uid);
			pstmt.setString(2, title);
			pstmt.setString(3, content);
			pstmt.setString(4, tag);
			pstmt.setTimestamp(5, new Timestamp(new Date().getTime()));
			
			if(pstmt.executeUpdate() > 0){
				print("{\"state\":1}");
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			db.freeConnection();
		}
		print("{\"state\":0}");
	}
	
	/**
	 * 管理推荐信息（删除）
	 */
	public void manage(){
		int uid = Tools.parseInt(getParameter("uid"));
		int tid = Tools.parseInt(getParameter("tid"));
		contentType("text/json;charset=UTF-8");
		
		DBOperate db = new DBOperate();
		try {
			String sql = "DELETE FROM recommend WHERE uid = ? AND id = ?";
			PreparedStatement pstmt = db.preparedStatement(sql);
			pstmt.setInt(1, uid);
			pstmt.setInt(2, tid);
			
			if(pstmt.executeUpdate() > 0){
				print("{\"state\":1}");
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			db.freeConnection();
		}
		print("{\"state\":0}");
	}
	
	/**
	 * 评论推荐信息
	 */
	public void reply(){
		int tid = Tools.parseInt(getParameter("tid"));
		int replyUid = Tools.parseInt(getParameter("replyUid"));
		String replyContent = getParameter("content");
		contentType("text/json;charset=UTF-8");
		
		DBOperate db = new DBOperate();
		try {
			String sql = "INSERT INTO recommendreply(tid,replyUid,replyContent,replyTime) VALUES(?,?,?,?)";
			PreparedStatement pstmt = db.preparedStatement(sql);
			pstmt.setInt(1, tid);
			pstmt.setInt(2, replyUid);
			pstmt.setString(3, replyContent);
			pstmt.setTimestamp(4, new Timestamp(new Date().getTime()));
			
			if(pstmt.executeUpdate() > 0){
				print("{\"state\":1}");
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			db.freeConnection();
		}
		print("{\"state\":0}");
	}
	
	/**
	 * 获取评论信息
	 */
	public void getReplys(){
		List<RecommendReply> replies = new ArrayList<>();
		int tid = Tools.parseInt(getParameter("tid"));
		contentType("text/json;charset=UTF-8");
		DBOperate db = new DBOperate();
		try {
			String sql = "select u.uid,u.nickName,u.headImage,rp.tid,rp.replyContent,rp.replyTime from recommendreply as rp inner join [user] as u on rp.replyUid = u.uid where rp.tid = ?";
			PreparedStatement pstmt = db.preparedStatement(sql);
			pstmt.setInt(1, tid);
			
			ResultSet rSet = pstmt.executeQuery();
			while(rSet.next()){
				RecommendReply reply = new RecommendReply();
				reply.setReplyUid(rSet.getInt("uid"));
				reply.setNickName(rSet.getString("nickName"));
				reply.setHeadImage(rSet.getString("headImage"));
				reply.setTid(rSet.getInt("tid"));
				reply.setReplyContent(rSet.getString("replyContent"));
				reply.setReplyTime(rSet.getString("replyTime"));
				
				replies.add(reply);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			db.freeConnection();
		}
		print(JSON.stringify(replies));
	} 
	
	/**
	 * 加关注
	 */
	public void addGz(){
		int myUid = Tools.parseInt(getParameter("myUid"));
		int gzUid = Tools.parseInt(getParameter("gzUid"));
		contentType("text/json;charset=UTF-8");
		if(isExistsGz(myUid, gzUid)){
			print("{\"state\":2}");
			return;
		}
		DBOperate db = new DBOperate();
		try {
			String sql = "INSERT INTO guanzhu(myUid,guanzhuUid,onTime) VALUES(?,?,?)";
			PreparedStatement pstmt = db.preparedStatement(sql);
			pstmt.setInt(1, myUid);
			pstmt.setInt(2, gzUid);
			pstmt.setTimestamp(3, new Timestamp(new Date().getTime()));
			
			if(pstmt.executeUpdate() > 0){
				print("{\"state\":1}");
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			db.freeConnection();
		}
		print("{\"state\":0}");
	}
	
	/**
	 * 获取我关注的用户信息
	 */
	public void getGuanzhu(){
		List<Fans> gfanList = new ArrayList<>();
		int myUid = Tools.parseInt(getParameter("myUid"));
		
		DBOperate db = new DBOperate();
		try {
			String sql = "SELECT g.id,g.myUid,g.guanzhuUid,u.headImage,u.nickName,u.qq,g.onTime FROM guanzhu as g INNER JOIN [user] as u ON g.guanzhuUid = u.uid WHERE myUid = ?";
			PreparedStatement pstmt = db.preparedStatement(sql);
			pstmt.setInt(1, myUid);
			
			ResultSet resultSet = pstmt.executeQuery();
			while(resultSet.next()){
				Fans gfans = new Fans();
				gfans.setId(resultSet.getInt("id"));
				gfans.setMyUid(resultSet.getInt("myUid"));
				gfans.setGuanzhuUid(resultSet.getInt("guanzhuUid"));
				gfans.setHeadImage(resultSet.getString("headImage"));
				gfans.setNickName(resultSet.getString("nickName"));
				gfans.setQq(resultSet.getString("qq"));
				gfans.setOnTime(resultSet.getString("onTime"));
				gfanList.add(gfans);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			db.freeConnection();
		}
		contentType("text/json;charset=UTF-8");
		print(JSON.stringify(gfanList));
	}
	
	/**
	 * 是否已经关注过
	 * @param myUid
	 * @param gzUid
	 * @return
	 */
	private boolean isExistsGz(int myUid,int gzUid){
		DBOperate db = new DBOperate();
		try {
			String sql = "SELECT id FROM guanzhu WHERE myUid = ? AND guanzhuUid = ?";
			PreparedStatement pstmt = db.preparedStatement(sql);
			pstmt.setInt(1, myUid);
			pstmt.setInt(2, gzUid);
			
			return pstmt.executeQuery().next();
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			db.freeConnection();
		}
		return false;
	}
	/**
	 * 取消关注
	 */
	public void cancelGz(){
		int myUid = Tools.parseInt(getParameter("myUid"));
		int gzUid = Tools.parseInt(getParameter("gzUid"));
		contentType("text/json;charset=UTF-8");
		
		DBOperate db = new DBOperate();
		try {
			String sql = "DELETE FROM guanzhu WHERE myUid = ? AND guanzhuUid = ?";
			PreparedStatement pstmt = db.preparedStatement(sql);
			pstmt.setInt(1, myUid);
			pstmt.setInt(2, gzUid);
			
			if(pstmt.executeUpdate() > 0){
				print("{\"state\":1}");
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			db.freeConnection();
		}
		print("{\"state\":0}");
	
	}
	
	/**
	 * 获取推荐信息
	 * 1.所有推荐信息
	 * 2.只看关注的人的推荐信息
	 * 3.按标签搜索
	 */
	public void recommands(){
		List<Recommand> recommands = new ArrayList<>();
		contentType("text/json;charset=UTF-8");
		int uid = Tools.parseInt(getParameter("uid"));
		int type = Tools.parseInt(getParameter("type"));
		String tagString = getParameter("tag");
		
		DBOperate db = new DBOperate();
		try {
			PreparedStatement pstmt = null;
			ResultSet resultSet = null;
			if(type == 1){
				// 所有推荐信息
				if(tagString != null){
					String sql = "select r.id,r.title,r.content,r.tag,r.uid,u.nickName from recommend as r inner join [user] as u on r.uid = u.uid where r.tag = ?";
					pstmt = db.preparedStatement(sql);
					pstmt.setString(1, tagString);
				}else{
					String sql = "select r.id,r.title,r.content,r.tag,r.uid,u.nickName from recommend as r inner join [user] as u on r.uid = u.uid";
					pstmt = db.preparedStatement(sql);
				}
			}else{
				// 只看关注的人的信息
				if(tagString != null){
					String sql = "select r.id,r.title,r.content,r.tag,r.uid,u.nickName from recommend as r inner join [user] as u on r.uid = u.uid where r.uid in (select guanzhuUid from guanzhu where myUid = ?) and r.tag = ?";
					pstmt = db.preparedStatement(sql);
					pstmt.setInt(1, uid);
					pstmt.setString(2, tagString);
				} else{
					String sql = "select r.id,r.title,r.content,r.tag,r.uid,u.nickName from recommend as r inner join [user] as u on r.uid = u.uid where r.uid in (select guanzhuUid from guanzhu where myUid = ?)";
					pstmt = db.preparedStatement(sql);
					pstmt.setInt(1, uid);
				}
			}
			
			resultSet = pstmt.executeQuery();
			while(resultSet.next()){
				Recommand rmd = new Recommand();
				rmd.setId(resultSet.getInt("id"));
				rmd.setTitle(resultSet.getString("title"));
				rmd.setContent(resultSet.getString("content"));
				rmd.setTag(resultSet.getString("tag"));
				rmd.setUid(resultSet.getInt("uid"));
				rmd.setNickName(resultSet.getString("nickName"));
				
				recommands.add(rmd);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			db.freeConnection();
		}
		print(JSON.stringify(recommands));
	}
	
	/**
	 * 获取我的所有推荐信息
	 */
	public void getMyRecommend(){
		List<Recommand> myRecommands = new ArrayList<>(); 
		contentType("text/json;charset=UTF-8");
		int uid = Tools.parseInt(getParameter("uid"));
		DBOperate db = new DBOperate();
		try {
			String sql = "SELECT * FROM recommend ";
			PreparedStatement pstmt = db.preparedStatement(sql);
//			pstmt.setInt(1, uid);
			
			ResultSet resultSet = pstmt.executeQuery();
			while(resultSet.next()){
				Recommand rmd = new Recommand();
				rmd.setId(resultSet.getInt("id"));
			
				rmd.setUid(resultSet.getInt("uid"));
				rmd.setTitle(resultSet.getString("title"));
				rmd.setContent(resultSet.getString("content"));
				rmd.setTag(resultSet.getString("tag"));
				rmd.setCreateTime(resultSet.getString("createTime"));
				myRecommands.add(rmd);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			db.freeConnection();
		}
		print(JSON.stringify(myRecommands));
	
	}
	
	/**
	 * 获取我的粉丝
	 */
	public void getFuns(){
		List<Fans> fanList = new ArrayList<>();
		int myUid = Tools.parseInt(getParameter("myUid"));
		
		DBOperate db = new DBOperate();
		try {
			String sql = "SELECT g.id,g.myUid,g.guanzhuUid,u.headImage,u.nickName,u.qq,g.onTime FROM guanzhu as g INNER JOIN [user] as u ON g.myUid = u.uid WHERE guanzhuUid = ?";
			PreparedStatement pstmt = db.preparedStatement(sql);
			pstmt.setInt(1, myUid);
			
			ResultSet resultSet = pstmt.executeQuery();
			while(resultSet.next()){
				Fans fans = new Fans();
				fans.setId(resultSet.getInt("id"));
				fans.setMyUid(resultSet.getInt("myUid"));
				fans.setGuanzhuUid(resultSet.getInt("guanzhuUid"));
				fans.setHeadImage(resultSet.getString("headImage"));
				fans.setNickName(resultSet.getString("nickName"));
				fans.setQq(resultSet.getString("qq"));
				fans.setOnTime(resultSet.getString("onTime"));
				fanList.add(fans);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			db.freeConnection();
		}
		contentType("text/json;charset=UTF-8");
		print(JSON.stringify(fanList));
	}
	
	/**
	 * 粉丝管理(删除)
	 */
	public void manageFans(){
		
		int myUid = Tools.parseInt(getParameter("myUid"));
		int gzUid = Tools.parseInt(getParameter("gzUid"));
		contentType("text/json;charset=UTF-8");
		
		DBOperate db = new DBOperate();
		try {
			String sql = "DELETE FROM guanzhu WHERE myUid = ? AND guanzhuUid = ?";
			PreparedStatement pstmt = db.preparedStatement(sql);
			pstmt.setInt(1, myUid);
			pstmt.setInt(2, gzUid);
			
			if(pstmt.executeUpdate() > 0){
				print("{\"state\":1}");
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			db.freeConnection();
		}
		print("{\"state\":0}");
	
	}
}
