﻿# Host: localhost  (Version: 5.6.11)
# Date: 2014-05-29 15:42:25
# Generator: MySQL-Front 5.3  (Build 4.13)

/*!40101 SET NAMES utf8 */;

#
# Source for table "guanzhu"
#

DROP TABLE IF EXISTS `guanzhu`;
CREATE TABLE `guanzhu` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `myUid` int(255) DEFAULT NULL,
  `guanzhuUid` int(255) DEFAULT NULL,
  `onTime` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "guanzhu"
#

INSERT INTO `guanzhu` VALUES (4,2,1,'2014-05-29 13:34:17'),(5,1,2,'2014-05-29 13:34:42'),(6,3,1,'2014-05-29 15:32:52'),(8,3,2,'2014-05-29 15:33:15'),(10,1,3,'2014-05-29 15:38:40');

#
# Source for table "recommend"
#

DROP TABLE IF EXISTS `recommend`;
CREATE TABLE `recommend` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(255) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `content` text,
  `tag` varchar(32) DEFAULT NULL,
  `createTime` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

#
# Data for table "recommend"
#

INSERT INTO `recommend` VALUES (3,1,'Crawler Script Template','爱的发发发','行','2014-05-28 23:33:27'),(4,1,'Rest API  Document Template','爱上对方的撒伐','食','2014-05-28 23:34:06'),(5,2,'同样一件事我们可以安慰别人，却说服不了自己。','同样一件事我们可以安慰别人，却说服不了自己。','其他','2014-05-29 11:15:23'),(7,3,'叮叮当','叮叮当叮叮当，铃儿响叮当。','行','2014-05-29 15:33:59');

#
# Source for table "recommendreply"
#

DROP TABLE IF EXISTS `recommendreply`;
CREATE TABLE `recommendreply` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(11) DEFAULT NULL,
  `replyUid` int(11) DEFAULT NULL,
  `replyContent` varchar(255) DEFAULT NULL,
  `replyTime` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "recommendreply"
#

INSERT INTO `recommendreply` VALUES (1,3,2,'划分方法方法发发发发发发','2014-05-29 15:08:48'),(2,3,2,'asdfafafafdsafsaf','2014-05-29 15:12:40'),(3,4,2,'fafdsafdsafdafdsadsafdsaf','2014-05-29 15:12:51'),(4,5,2,'afdafdsafdsafdsafdsafdsafdsafdsafdafdsafdsafdsafdsa','2014-05-29 15:12:56'),(5,5,1,'有深度，有内涵','2014-05-29 15:28:22'),(6,5,3,'路过','2014-05-29 15:34:48');

#
# Source for table "user"
#

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `loginName` varchar(50) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `nickName` varchar(50) DEFAULT NULL,
  `headImage` varchar(255) DEFAULT NULL,
  `qq` varchar(50) DEFAULT NULL,
  `regTime` datetime DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `Uq_loginName` (`loginName`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# Data for table "user"
#

INSERT INTO `user` VALUES (1,'barry','111111','风继续吹','http://mxyc.qiniudn.com/images/images/72/71/97/ial_1398040311506.jpg','48417192','2014-05-28 22:17:02'),(2,'jake','111111','杰克','','12344213','2014-05-29 11:02:41'),(3,'tina','111111','缇娜','','3334212','2014-05-29 15:32:05');
